<?php header('Access-Control-Allow-Origin: *'); ?>
<!--<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN"
                      "http://www.w3.org/TR/html4/strict.dtd">-->
<!DOCTYPE html>


<html><!-- InstanceBegin template="/Templates/pangloss_seconde-navgauche.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Language" content="fr">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- InstanceBeginEditable name="doctitle" -->
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

<title>Ressource</title>
<!-- InstanceEndEditable -->
<link rel="stylesheet" type="text/css" href="../../styles/xcharte.css">
<link rel="stylesheet" type="text/css" href="../../styles/styles.css">
<script src="../../Scripts/Change_Version.js" type="text/javascript"></script>
<script language="JavaScript" src="../../z-outils/init.js"></script>
<script language="JavaScript" src="../../z-outils/outils.js"></script>
<script language="JavaScript" type="text/JavaScript">
    
<!-- Matthew DEO : intégration du plug-in Eastlingplayer -->    

<script src="./eastling-js/jquery-1.11.0.js"></script>
<script src="./eastling-js/jquery.maphilight.js"></script>
<script src="./eastling-js/eastlingplayer.js"></script>
<script src="./eastling-js/html5PlayerManager_md.js"></script>
<script src="./eastling-js/divtotable.js"></script>    
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);

function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<!-- InstanceBeginEditable name="head" --><!-- InstanceEndEditable -->
<style type="text/css">
<!--
.Style1 {color: #820E12}
-->
</style>
</head>
<body marginwidth="0" marginheight="0" >

  <!--<div class="bandeau-liens" id="divbandeau-lienCNRS"> <a href="http://www.cnrs.fr/fr/organisme/presentation.htm" target="_blank">Le CNRS</a> </div>
<div id="divbandeau-traitvert1"><img src="../z-outils/images/charte/trait-vertical.gif"></div>
  <div id="divbandeau-lienAccueil" class="bandeau-liens"> <a href="http://www.cnrs.fr/shs/" target="_blank">Accueil SHS</a> </div>
<div id="divbandeau-traitvert2"><img src="../z-outils/images/charte/trait-vertical.gif"></div>
  <div id="divbandeau-lienAutres" class="bandeau-liens"><a href="http://www.cnrs.fr/fr/une/sites-cnrs.htm" target="_blank">Autres sites CNRS</a></div> 
<div id="divbandeau-traitvert3"><img src="../z-outils/images/charte/trait-vertical.gif"></div>-->

<table height="100%" width="100%"  bgcolor="#CCCCCC">
<tr>
<td >


<table height="100%" width="1000"  border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#FFFFFF">
  <tr>
   
    <td background="../../../../../z-outils/images/charte/bandeau-haut-droit_ok.gif" align="left" ><table width="1000"><tr><td width="454" valign="top" class="Xnavhaut"><p> <a href="file:///C|/Program Files (x86)/EasyPHP-12.1/www/index.htm"><img src="../../../../../images/logos/Logo_Lacito.png" alt="aa" width="141" height="59" hspace="10" border="0" align="left"></a></p> <span class="Style1">Langues et civilisations<br>
        à tradition orale <br>
        (UMR7107)</span></p></td><td width="534" class="bandeau-liens">&nbsp;&nbsp;&nbsp;&nbsp;  
<img src="../../../../../z-outils/images/charte/trait-vertical.gif">&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://www.cnrs.fr/fr/organisme/presentation.htm" target="_blank">Le CNRS</a>
&nbsp;&nbsp;&nbsp;&nbsp;  
<img src="../../../../../z-outils/images/charte/trait-vertical.gif">
&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://www.cnrs.fr/shs/" target="_blank">Accueil SHS</a>&nbsp;&nbsp;&nbsp;&nbsp;  
<img src="../../../../../z-outils/images/charte/trait-vertical.gif">
&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://www.cnrs.fr/fr/une/sites-cnrs.htm" target="_blank">Autres sites CNRS</a>
&nbsp;&nbsp;&nbsp;&nbsp;  
<img src="../../../../../z-outils/images/charte/trait-vertical.gif">
&nbsp;&nbsp;&nbsp;&nbsp;
</td></tr></table>
        
     </td>
    <!--<img src="../z-outils/images/charte/bandeau-haut-droit.gif" alt="" width="100%" height="66" border="0"/></td>-->
    
  </tr>
  
  <tr>
   
    
    <td width="1000"  align="center" height="125" ><!-- InstanceBeginEditable name="Visuel" --><a href="../index.htm"><img src="../../../../../images/bandeaux/bandeau_archivage1.jpg" alt="archivage" width="100%" height="142" border="0"></a><!-- InstanceEndEditable --></td>
   
  </tr>
  <tr>
  <td>
  
  <table border="0" cellpadding="3" cellspacing="0"  width="100%">
      			<tr>
                <td colspan="7" align="center">
                <!--<table width="100%"><tr>
                <td height="55" align="left"><a href="http://www.cnrs.fr" target="_blank"><img src="../images/logos/logo-cnrs.jpg" alt="cnrs" width="88" height="36" border="0"/></a></td>
                <td align="center"><a href="http://www.univ-paris3.fr/1207750810633/0/fiche___defaultstructureksup/&RH=1235649944785" target="_blank"><img src="../images/logos/logo-paris-3.gif" alt="paris3" width="150" height="53" border="0"/></a></td>
                <td align="center"><a href="http://www.paris-sorbonne.fr/fr/spip.php?rubrique1096" target="_blank"><img src="../images/logos/logo-paris-4.gif" alt="paris4" width="150" height="53" border="0"/></a></td>
                 <td align="right"><a href="http://www.typologie.cnrs.fr/" target="_blank"><img src="../images/logos/logo-typo.gif" alt="tul" width="150" height="53" border="0"/></a></td>
                 </tr></table>-->
                </td>
                </tr>
                <tr>
       	 			<td width="9%" height="50" align="left" class="Xnavgauche"> 
                                    <a href="http://www.cnrs.fr" target="_blank"><img src="../../../../../images/logos/cnrs.jpg" alt="CNRS" width="65" height="64"  border="0"/></a></td>
                    <td width="14%" height="50" align="left" class="Xnavgauche">
                        <a href="http://cocoon.huma-num.fr" target="_blank"><img src="../../../../../images/logos/cocoon2.png" alt="Cocoon" width="120" height="42" border="0"/></a></td>
                    <td width="10%" height="50" align="left" class="Xnavgauche">
                        <a href="http://www.huma-num.fr/" target="_blank"><img src="../../../../../images/logos/huma-num.jpg" alt="Huma-Num" width="80" height="45"  border="0"/></a></td>
                     <td width="11%" class="Xnavgauche" align="left">
                         <a href="http://www.labex-efl.org/" target="_blank"><img src="../../../../../images/logos/logoefl.jpg" alt="Labex-EFL" width="90" height="48"  border="0"/></a></td>
                     <td width="11%" class="Xnavgauche" align="left">
                         <a href="http://www.agence-nationale-recherche.fr/" target="_blank"><img src="../../../../../images/logos/ANR.gif" alt="ANR" width="80" height="42" border="0"/></a></td>
                   <!-- <td width="41%" height="50" align="right" class="Xnavgauche"> <br/>
                    <form name="rechercher-spm"
action="http://lacito.vjf.cnrs.fr/moteur/engine.php" method="GET">
				<b>Rechercher </b><input type="hidden" name="action"  value="go">
	<input name ="blork" maxLength="50" size="10" class="text"/><input
name="submit2" type="image" src="../z-outils/images/charte/ok.gif"
align="texttop"
                            border="0" width="20" height="20"/></form></td>-->
                   <!-- <td width="10%" height="50" align="right" class="Xnavgauche"><a href="../../INTRANET/index.htm"><b style="text-decoration : none">Intranet</b> <img border="0" src="../z-outils/images/boite-outils/icones/intranet.gif" width="18" height="12" alt="Lacito"/></a></td>-->
                   <td width="10%" class="Xnavgauche" align="right"><a href="Javascript:version()"><img src="../../../../../images/logos/eng.gif" alt="English" width="47" height="47"  border="0"></a></td>
      			</tr>
       		</table>
  
  </td>
  </tr>
 
  <tr>
 
    
    <td class="Xchemin" height="60"> 
    <br/><br/><br/><br/>
    &nbsp;<!-- InstanceBeginEditable name="Chemin" --><a href="../../index.htm">&nbsp;Accueil Lacito</a> &gt; <a href="../index.htm">Accueil Pangloss</a><!-- InstanceEndEditable --></td>
   
  </tr>
  
  <tr>
  
    
    <td width="1056" class="Xtextcourant" valign="top" ><div id="ZonePrint">
      <!-- InstanceBeginEditable name="Contenu" -->
				<!--
					$title= isset($_GET["title"])    ? utf8_encode($_GET["title"])    : "*";
					$lg= isset($_GET["lg"])    ? utf8_encode($_GET["lg"])    : "*";
					$id= isset($_GET["id"])    ? utf8_encode($_GET["id"])    : "*";
					echo ("<span style=\"text-align:right\"><a href=\"MdR.php?id={$id}&title={$title}&lg={$lg}\"><b>Recherche Linguistique &lt;&lt;</b></a></span>");
				-->
               

               
               <!-- <audio id='aplayer' src="http://fedora.tge-adonis.fr:8090/fedora/get/CRDO-Paris:6537/DEPOT_POISSON_22km.wav" type="audio/wav; codecs=pcm" onTimeUpdate="update();" onEnded="trackEnded();" >
                <b>Your browser does not support the <code>audio</code> element. </b>

		</audio>-->
        
        
      
        
        <table width="100%" height="400">
<tr><td valign="top">
    <div class="eastling">             
            <!--<audio class="eastlingplayer" id="player" src="" controls></audio>-->
        </div>

        <script>
            var first_play = true;
            var phraseEnCours = "";
            
            $(document).ready(function () {
                // METTRE CETTE PARTIE DANS UN JS A PART
                //var strokeColor = "0055cc";
                var strokeColor = "FF0000"; //!!toujours mettre le code couleur hexadecimal !!
                var strokeWidth = 4;
                var fillColor = "ffffff";
                var fillOpacity = 0.0;
                
                function word_highlight(dom,highlight,strokeWidth,strokeColor){
                    if(highlight){
                        dom.css('border-style','solid');
                        dom.css('border-width',strokeWidth+'px');
                        dom.css('border-color','#'+strokeColor);
                    }else{
                        dom.css('border-style','none');
                        dom.css('border-width','0px');
                    }
                }
                //////////////////
                
                
                var metadata;
                var annotations;
                var url_image;
                var url_audio;

                $('.eastling').eastlingplayer({                  
                    idref : "<?php echo $_GET['idref']; ?>",
                    strokeColor: strokeColor,
                    strokeWidth: strokeWidth,
                    fillColor: fillColor,
                    fillOpacity: fillOpacity,
                    callback:function(){
                        
                        $('.map').maphilight();
                        
                       $('.eastling').divtotable();
                        
                        //surlignage de la zone sur survol du mot
                        $('.word').bind('mouseover',function(){
                         var link = $(this).attr('link');                        
                         $('#'+link).mouseover();
                         word_highlight($(this),true,strokeWidth,strokeColor);
                         
                        }).bind('mouseout',function(){
                            var link = $(this).attr('link');
                            $('#'+link).mouseout();
                            word_highlight($(this),false,'','');
                            
                        });
                        
                        $('area').bind('mouseover',function(){
                            var link = $(this).attr('id');
                            word_highlight($("[link='"+link+"']"),true,strokeWidth,strokeColor);
                        }).bind('mouseout',function(){
                            var link = $(this).attr('id');
                            word_highlight($("[link='"+link+"']"),false,'','');
                        });
                        
                        var p = $("#player")[0];
                p.addEventListener("play", function() { 
                    if (first_play){
                        first_play = false;
                        var idSentence = $('.playFrom:first').parent().attr('id');
                        playFrom(idSentence);
                    }
                }, true);
                
                                          
                    
                    }
                });
                               

            });
        </script>     
        

</td></tr></table>

<!-- InstanceEndEditable --></div>
    </td>
 </tr>
 <tr>
        <td>
        <table border="0">
        <tr>
    <td width="1000" class="XnavgaucheIcones" align="center">
        <!--<img src="../../z-outils/images/charte/icones-01.gif" alt="" width="150" height="55" border="0" usemap="#Map2">-->
    </td>
   
  </tr>
  </table>
  </td>
  </tr> 
</table>

<p>
  <script type='text/javascript'>function Go(){return}</script>
     <script type='text/javascript' src='../../../../../z-outils/deroulants/pangloss_top_pos_var.js'></script>
     <script type='text/javascript' src='../../../../../z-outils/deroulants/pangloss_menu_var.js'></script>
     <script type='text/javascript' src='../../../../../z-outils/deroulants/pangloss_menu9_com.js'></script>
</p>
<noscript>
 <p>Your browser does not support script</p>
</noscript>

<map name="Map2">
  <area shape="rect" coords="28,23,46,43" href="javascript:impression()" alt="Imprimer">
  <area shape="rect" coords="49,22,66,42" href="javascript:writemail('vjf.cnrs.fr','behaghel','',1);" alt="Contacter le webmestre">
  <area shape="rect" coords="68,23,85,43" href="file:///C|/Program Files (x86)/EasyPHP-12.1/www/pratique/index.htm" alt="Plan du site">
  <area shape="rect" coords="87,23,105,43" href="file:///C|/Program Files (x86)/EasyPHP-12.1/www/pratique/credits.htm" alt="Crédits">
  <area shape="rect" coords="9,24,25,43" href="file:///C|/Program Files (x86)/EasyPHP-12.1/www/index.htm" alt="Accueil">
</map>

  </td>
  </tr>
</table>






</body>
<!-- InstanceEnd --></html>